import React, { useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    FlatList,
    StyleSheet,
    ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import AvatarUsuario from '../components/AvatarUsuario';

export default function Chamados() {
    const [status, setStatus] = useState<'A' | 'F' | null>(null);
    const [loading, setLoading] = useState(false);
    const [chamados, setChamados] = useState([]);
    const [menuAberto, setMenuAberto] = useState<number | null>(null);

    const buscarChamados = async (tipo: 'A' | 'F') => {
        setStatus(tipo);
        setLoading(true);
        const token = await AsyncStorage.getItem('auth_token');

        try {
            const response = await fetch(
                `http://127.0.0.1:8000/api/v1/calleds?tableFilters[status_aberto][value]=${
                    tipo === 'A' ? 'abertos' : 'fechados'
                }`,
                {
                    headers: {
                        Accept: 'application/json',
                        Authorization: `Bearer ${token}`,
                    },
                }
            );

            const json = await response.json();
            setChamados(json.data || []);
        } catch (error) {
            console.error('Erro ao buscar chamados:', error);
        } finally {
            setLoading(false);
        }
    };

    const formatarData = (data: string) => {
        const d = new Date(data);
        return d.toLocaleDateString('pt-BR');
    };

    return (
        <View style={styles.container}>
            <View style={styles.pageHeader}>
                <Text style={styles.title}>CHAMADOS</Text>
                <AvatarUsuario />
            </View>

            <Text style={styles.subtitle}>Meus Chamados</Text>

            <View style={styles.filters}>
                <TouchableOpacity
                    onPress={() => buscarChamados('A')}
                    style={[styles.button, status === 'A' && styles.buttonSelected]}
                >
                    <Text style={styles.buttonText}>Abertos</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    onPress={() => buscarChamados('F')}
                    style={[styles.button, status === 'F' && styles.buttonSelected]}
                >
                    <Text style={styles.buttonText}>Fechados</Text>
                </TouchableOpacity>
            </View>

            {loading ? (
                <ActivityIndicator size="large" />
            ) : (
                <FlatList
                    data={chamados}
                    keyExtractor={(item) => String(item.id)}
                    renderItem={({ item }) => (
                        <View style={styles.card}>
                            <Text style={styles.protocolo}>{item.protocolo}</Text>
                            <Text style={styles.problem}>{item.problem}</Text>
                            <View style={styles.infoRow}>
                                <Text style={styles.label}>Setor:</Text>
                                <Text style={styles.value}>{item.sector?.name}</Text>
                            </View>
                            <View style={styles.infoRow}>
                                <Text style={styles.label}>Status:</Text>
                                <Text style={[styles.value, item.closing_date ? styles.fechado : styles.aberto]}>
                                    {item.closing_date ? 'Fechado' : 'Aberto'}
                                </Text>
                            </View>
                            <View style={styles.infoRow}>
                                <Text style={styles.label}>Responsável:</Text>
                                <Text style={styles.value}>{item.user?.name}</Text>
                            </View>
                            <View style={styles.infoRow}>
                                <Text style={styles.label}>Data:</Text>
                                <Text style={styles.value}>{formatarData(item.created_at)}</Text>
                            </View>

                            <View style={styles.actionMenu}>
                                <TouchableOpacity
                                    onPress={() => setMenuAberto(menuAberto === item.id ? null : item.id)}
                                    style={styles.actionToggle}
                                >
                                    <Text style={styles.actionToggleText}>Ações</Text>
                                </TouchableOpacity>
                                {menuAberto === item.id && (
                                    <View style={styles.actionDropdown}>
                                        <TouchableOpacity onPress={() => console.log('Dar baixa', item.id)}>
                                            <Text style={styles.actionItem}>Dar Baixa</Text>
                                        </TouchableOpacity>
                                        <TouchableOpacity onPress={() => console.log('Interações', item.id)}>
                                            <Text style={styles.actionItem}>Interações</Text>
                                        </TouchableOpacity>
                                    </View>
                                )}
                            </View>
                        </View>
                    )}
                />
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, backgroundColor: '#f4f4f4' },
    pageHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 12,
    },
    title: { fontSize: 16, fontWeight: 'bold' },
    subtitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 10 },
    filters: { flexDirection: 'row', gap: 10, marginBottom: 20 },
    button: {
        backgroundColor: '#007bff',
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 8,
    },
    buttonSelected: {
        backgroundColor: '#0056b3',
    },
    buttonText: { color: '#fff', fontWeight: 'bold' },
    card: {
        backgroundColor: '#fff',
        padding: 12,
        borderRadius: 10,
        marginBottom: 12,
        elevation: 2,
    },
    protocolo: {
        fontWeight: 'bold',
        fontSize: 16,
        marginBottom: 4,
        color: '#222',
    },
    problem: {
        fontSize: 14,
        color: '#444',
        marginBottom: 8,
    },
    infoRow: {
        flexDirection: 'row',
        marginTop: 2,
    },
    label: {
        fontWeight: '600',
        marginRight: 4,
    },
    value: {
        color: '#555',
    },
    aberto: {
        color: '#2e7d32',
        fontWeight: 'bold',
    },
    fechado: {
        color: '#c62828',
        fontWeight: 'bold',
    },
    actionMenu: {
        marginTop: 12,
        alignItems: 'flex-end',
    },
    actionToggle: {
        backgroundColor: '#f39c12',
        paddingVertical: 6,
        paddingHorizontal: 12,
        borderRadius: 6,
    },
    actionToggleText: {
        color: '#fff',
        fontWeight: 'bold',
    },
    actionDropdown: {
        marginTop: 6,
        backgroundColor: '#fff',
        borderWidth: 1,
        borderColor: '#ccc',
        borderRadius: 6,
        padding: 6,
        width: 140,
    },
    actionItem: {
        paddingVertical: 6,
        fontSize: 14,
        color: '#007bff',
    },
});
