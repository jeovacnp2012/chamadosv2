import { Tabs } from 'expo-router';

export default function TabsLayout() {
    return (
        <Tabs>
            <Tabs.Screen name="home" options={{ title: 'HOME' }} />
            <Tabs.Screen name="chamados" options={{ title: 'CHAMADOS' }} />
            <Tabs.Screen name="relatorios" options={{ title: 'RELATÓRIOS' }} />
        </Tabs>
    );
}
