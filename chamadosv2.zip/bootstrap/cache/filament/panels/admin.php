<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.address-resource.pages.create-address' => 'App\\Filament\\Resources\\AddressResource\\Pages\\CreateAddress',
    'app.filament.resources.address-resource.pages.edit-address' => 'App\\Filament\\Resources\\AddressResource\\Pages\\EditAddress',
    'app.filament.resources.address-resource.pages.list-addresses' => 'App\\Filament\\Resources\\AddressResource\\Pages\\ListAddresses',
    'app.filament.resources.agreement-item-resource.pages.create-agreement-item' => 'App\\Filament\\Resources\\AgreementItemResource\\Pages\\CreateAgreementItem',
    'app.filament.resources.agreement-item-resource.pages.edit-agreement-item' => 'App\\Filament\\Resources\\AgreementItemResource\\Pages\\EditAgreementItem',
    'app.filament.resources.agreement-item-resource.pages.list-agreement-items' => 'App\\Filament\\Resources\\AgreementItemResource\\Pages\\ListAgreementItems',
    'app.filament.resources.called-resource.pages.chat-page' => 'App\\Filament\\Resources\\CalledResource\\Pages\\ChatPage',
    'app.filament.resources.called-resource.pages.create-called' => 'App\\Filament\\Resources\\CalledResource\\Pages\\CreateCalled',
    'app.filament.resources.called-resource.pages.edit-called' => 'App\\Filament\\Resources\\CalledResource\\Pages\\EditCalled',
    'app.filament.resources.called-resource.pages.list-calleds' => 'App\\Filament\\Resources\\CalledResource\\Pages\\ListCalleds',
    'app.filament.resources.company-resource.pages.create-company' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\CreateCompany',
    'app.filament.resources.company-resource.pages.edit-company' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\EditCompany',
    'app.filament.resources.company-resource.pages.list-companies' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\ListCompanies',
    'app.filament.resources.company-resource.pages.view-company' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\ViewCompany',
    'app.filament.resources.departament-resource.pages.create-departament' => 'App\\Filament\\Resources\\DepartamentResource\\Pages\\CreateDepartament',
    'app.filament.resources.departament-resource.pages.edit-departament' => 'App\\Filament\\Resources\\DepartamentResource\\Pages\\EditDepartament',
    'app.filament.resources.departament-resource.pages.list-departaments' => 'App\\Filament\\Resources\\DepartamentResource\\Pages\\ListDepartaments',
    'app.filament.resources.departament-resource.pages.view-departament' => 'App\\Filament\\Resources\\DepartamentResource\\Pages\\ViewDepartament',
    'app.filament.resources.patrimony-resource.pages.create-patrimony' => 'App\\Filament\\Resources\\PatrimonyResource\\Pages\\CreatePatrimony',
    'app.filament.resources.patrimony-resource.pages.edit-patrimony' => 'App\\Filament\\Resources\\PatrimonyResource\\Pages\\EditPatrimony',
    'app.filament.resources.patrimony-resource.pages.list-patrimonies' => 'App\\Filament\\Resources\\PatrimonyResource\\Pages\\ListPatrimonies',
    'app.filament.resources.patrimony-resource.pages.view-patrimony' => 'App\\Filament\\Resources\\PatrimonyResource\\Pages\\ViewPatrimony',
    'app.filament.resources.permission-resource.pages.create-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\CreatePermission',
    'app.filament.resources.permission-resource.pages.edit-permission' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\EditPermission',
    'app.filament.resources.permission-resource.pages.list-permissions' => 'App\\Filament\\Resources\\PermissionResource\\Pages\\ListPermissions',
    'app.filament.resources.price-agreement-resource.pages.create-price-agreement' => 'App\\Filament\\Resources\\PriceAgreementResource\\Pages\\CreatePriceAgreement',
    'app.filament.resources.price-agreement-resource.pages.edit-price-agreement' => 'App\\Filament\\Resources\\PriceAgreementResource\\Pages\\EditPriceAgreement',
    'app.filament.resources.price-agreement-resource.pages.list-price-agreements' => 'App\\Filament\\Resources\\PriceAgreementResource\\Pages\\ListPriceAgreements',
    'app.filament.resources.role-resource.pages.create-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\CreateRole',
    'app.filament.resources.role-resource.pages.edit-role' => 'App\\Filament\\Resources\\RoleResource\\Pages\\EditRole',
    'app.filament.resources.role-resource.pages.list-roles' => 'App\\Filament\\Resources\\RoleResource\\Pages\\ListRoles',
    'app.filament.resources.sector-resource.pages.create-sector' => 'App\\Filament\\Resources\\SectorResource\\Pages\\CreateSector',
    'app.filament.resources.sector-resource.pages.edit-sector' => 'App\\Filament\\Resources\\SectorResource\\Pages\\EditSector',
    'app.filament.resources.sector-resource.pages.list-sectors' => 'App\\Filament\\Resources\\SectorResource\\Pages\\ListSectors',
    'app.filament.resources.sector-resource.pages.view-sector' => 'App\\Filament\\Resources\\SectorResource\\Pages\\ViewSector',
    'app.filament.resources.supplier-resource.pages.create-supplier' => 'App\\Filament\\Resources\\SupplierResource\\Pages\\CreateSupplier',
    'app.filament.resources.supplier-resource.pages.edit-supplier' => 'App\\Filament\\Resources\\SupplierResource\\Pages\\EditSupplier',
    'app.filament.resources.supplier-resource.pages.list-suppliers' => 'App\\Filament\\Resources\\SupplierResource\\Pages\\ListSuppliers',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'filament.pages.dashboard' => 'Filament\\Pages\\Dashboard',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    0 => 'Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\projeotos\\chamadosv2\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\AddressResource.php' => 'App\\Filament\\Resources\\AddressResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\AgreementItemResource.php' => 'App\\Filament\\Resources\\AgreementItemResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\CalledResource.php' => 'App\\Filament\\Resources\\CalledResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\CompanyResource.php' => 'App\\Filament\\Resources\\CompanyResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\DepartamentResource.php' => 'App\\Filament\\Resources\\DepartamentResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\PatrimonyResource.php' => 'App\\Filament\\Resources\\PatrimonyResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\PermissionResource.php' => 'App\\Filament\\Resources\\PermissionResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\PriceAgreementResource.php' => 'App\\Filament\\Resources\\PriceAgreementResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\RoleResource.php' => 'App\\Filament\\Resources\\RoleResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\SectorResource.php' => 'App\\Filament\\Resources\\SectorResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\SupplierResource.php' => 'App\\Filament\\Resources\\SupplierResource',
    'C:\\projeotos\\chamadosv2\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\projeotos\\chamadosv2\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\projeotos\\chamadosv2\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);