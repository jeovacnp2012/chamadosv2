<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CompanyScopeServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
];
