<div>
    <div class="space-y-3">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $recentMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-3 border border-gray-300 rounded-xl bg-white shadow-sm text-xs">
                <div class="flex items-center justify-between mb-1">
                    <span class="font-semibold text-gray-700"><?php echo e($message->user->name ?? 'Usuário Desconhecido'); ?></span>
                    <span class="text-gray-400"><?php echo e($message->created_at->format('d/m/Y H:i')); ?></span>
                </div>

                <div class="text-gray-800"><?php echo e($message->message); ?></div>

                <!--[if BLOCK]><![endif]--><?php if($message->attachment_path): ?>
                    <?php $ext = pathinfo($message->attachment_path, PATHINFO_EXTENSION); ?>
                    <div class="mt-2">
                        <a href="<?php echo e(Storage::url($message->attachment_path)); ?>" target="_blank" class="text-blue-500 underline">
                            Ver Anexo (<?php echo e(strtoupper($ext)); ?>)
                        </a>
                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->










                <div>
                    <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'danger','icon' => 'heroicon-o-trash','size' => 'sm','wire:click' => 'deleteMessage('.e($message->id).')','onclick' => 'return confirm(\'Tem certeza que deseja excluir esta mensagem?\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'danger','icon' => 'heroicon-o-trash','size' => 'sm','wire:click' => 'deleteMessage('.e($message->id).')','onclick' => 'return confirm(\'Tem certeza que deseja excluir esta mensagem?\')']); ?>
                        Excluir
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    <div class="mt-4">
        <?php echo e($recentMessages->links()); ?>

    </div>
</div>
<?php /**PATH C:\projeotos\chamadosv2\resources\views/livewire/called-messages.blade.php ENDPATH**/ ?>