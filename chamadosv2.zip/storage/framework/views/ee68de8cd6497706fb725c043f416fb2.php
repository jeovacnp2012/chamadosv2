<div>
<form wire:submit.prevent="save" class="space-y-4 p-4">
    <div>
        <label class="block text-xs font-bold mb-1">Mensagem</label>
        <textarea wire:model.defer="message" rows="3" class="w-full border rounded p-2 text-xs" required></textarea>
    </div>

    <div>
        <label class="block text-xs font-bold mb-1">Anexo (opcional)</label>
        <input type="file" wire:model="attachment" class="text-xs">

        <?php if($attachment): ?>
            <div class="mt-2 text-xs text-gray-700">
                <strong>Prévia do Anexo:</strong>
                <?php if($attachment->extension() === 'pdf'): ?>
                    📄 <?php echo e($attachment->getClientOriginalName()); ?>

                <?php elseif(in_array($attachment->extension(), ['jpg', 'jpeg', 'png', 'gif'])): ?>
                    <img src="<?php echo e($attachment->temporaryUrl()); ?>" class="max-w-xs mt-1 rounded border shadow">
                <?php else: ?>
                    📎 <?php echo e($attachment->getClientOriginalName()); ?>

                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <div class="text-right">
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
            Enviar
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
    </div>
</form>
</div>
<?php /**PATH C:\projeotos\chamadosv2\resources\views\livewire\send-message-form.blade.php ENDPATH**/ ?>