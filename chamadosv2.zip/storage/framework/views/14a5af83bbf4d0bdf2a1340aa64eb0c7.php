<?php if (isset($component)) { $__componentOriginalbe23554f7bded3778895289146189db7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbe23554f7bded3778895289146189db7 = $attributes; } ?>
<?php $component = Filament\View\LegacyComponents\Page::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Filament\View\LegacyComponents\Page::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <h2 class="text-lg font-bold mb-6 flex items-center gap-2">
        <?php if (isset($component)) { $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c = $attributes; } ?>
<?php $component = BladeUI\Icons\Components\Svg::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('heroicon-o-chat-bubble-left-right'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\BladeUI\Icons\Components\Svg::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-6 h-6 text-primary']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $attributes = $__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__attributesOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c)): ?>
<?php $component = $__componentOriginal643fe1b47aec0b76658e1a0200b34b2c; ?>
<?php unset($__componentOriginal643fe1b47aec0b76658e1a0200b34b2c); ?>
<?php endif; ?>
        Chat do Chamado
    </h2>

    
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div class="bg-white rounded-xl shadow p-4 space-y-2 border text-xs">
            <h3 class="text-sm font-bold text-gray-700 mb-2">📌 Informações Gerais</h3>
            <p><strong>Protocolo:</strong> <?php echo e($record->protocol); ?></p>
            <p><strong>Status:</strong> <?php echo e($record->status); ?></p>
            <p><strong>Descrição:</strong> <?php echo e($record->description); ?></p>
            <p><strong>Data de Abertura:</strong> <?php echo e($record->created_at->format('d/m/Y H:i')); ?></p>
            <p><strong>Data de Encerramento:</strong> <?php echo e($record->closing_date ? $record->closing_date->format('d/m/Y H:i') : '—'); ?></p>
        </div>
        <div class="bg-white rounded-xl shadow p-4 space-y-2 border text-xs">
            <h3 class="text-sm font-bold text-gray-700 mb-2">👤 Envolvidos e Local</h3>
            <p><strong>Solicitante:</strong> <?php echo e($record->user->name ?? '—'); ?></p>
            <p><strong>Executor:</strong> <?php echo e($record->executor->name ?? '—'); ?></p>
            <p><strong>Setor:</strong> <?php echo e($record->sector->name ?? '—'); ?></p>
            <p><strong>Departamento:</strong> <?php echo e($record->sector->departament->name ?? '—'); ?></p>
            <p><strong>Plaqueta Patrimônio:</strong> <?php echo e($record->patrimony_tag ?? '—'); ?></p>
        </div>
    </div>

    
    <div class="mb-4">
        <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'primary','xData' => true,'@click' => '$dispatch(\'open-send-message\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'primary','x-data' => true,'@click' => '$dispatch(\'open-send-message\')']); ?>
            Nova Mensagem
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
    </div>

    
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('called-messages', ['called' => $record]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3597657205-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

    
    <div class="mt-4 no-print">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('send-message-form', ['called' => $record]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3597657205-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>


    

    //CSS manual para esconder o componente evio de mensagem no print
    <style>
        @media print {
            .no-print {
                display: none !important;
            }
        }
    </style>

    
    <script>
        document.addEventListener('livewire:initialized', () => {
            Livewire.on('notify', event => {
                window.Filament?.notifications?.notify({
                    type: event.type,
                    title: event.message,
                });
            });
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $attributes = $__attributesOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__attributesOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbe23554f7bded3778895289146189db7)): ?>
<?php $component = $__componentOriginalbe23554f7bded3778895289146189db7; ?>
<?php unset($__componentOriginalbe23554f7bded3778895289146189db7); ?>
<?php endif; ?>
<script>
    Livewire.on('notify', ({ type, message }) => {
        window.Filament?.notifications?.notify({ type, title: message });
    });
</script>
<script>
    Livewire.on('notify', ({ type, message }) => {
        window.Filament?.notifications?.notify({
            type: type,
            title: message,
        });
    });
</script>

<?php /**PATH C:\projeotos\chamadosv2\resources\views\filament\resources\called-resource\pages\chat-page.blade.php ENDPATH**/ ?>