<?php use Filament\Support\Facades\FilamentAsset; ?>
<div xmlns:x-filament="http://www.w3.org/1999/html"
     x-load-js="['https://unpkg.com/html5-qrcode']"
     x-data="{
        html5QrcodeScanner: null,
        stopScanning() {
           if(!this.html5QrcodeScanner) {
               return;
           }
           this.html5QrcodeScanner.pause();
           this.html5QrcodeScanner.clear();
           this.html5QrcodeScanner = null;
        },
        openScannerModal() {
            $dispatch('open-modal', { id: 'qrcode-scanner-modal-<?php echo e($getName()); ?>' });
            this.startCamera();
        },
        closeScannerModal() {
            $dispatch('close-modal', { id: 'qrcode-scanner-modal-<?php echo e($getName()); ?>' });
            this.stopScanning();
        },
        onScanSuccess(decodedText, decodedResult) {
            $wire.set('<?php echo e($getId()); ?>', decodedText);
            $dispatch('close-modal', { id: 'qrcode-scanner-modal-<?php echo e($getName()); ?>' });
            this.stopScanning();
        },
        startCamera() {
            this.html5QrcodeScanner = new Html5QrcodeScanner('reader-<?php echo e($getName()); ?>', { fps: 10, qrbox: {width: 250, height: 250} }, false);
            this.html5QrcodeScanner.render(this.onScanSuccess);
         }
     }"
>
    <div class="grid gap-y-2">
        <div class="flex items-center gap-x-3 justify-between">
            <label for="<?php echo e($getId()); ?>" class="fi-fo-field-wrp-label inline-flex items-center gap-x-3">
                <span class="text-sm font-medium leading-6 text-gray-950 dark:text-white">
                    <?php echo e($getLabel() ?? 'Input Label'); ?>

                    <?php if($isRequired()): ?>
                        <sup class="text-danger-600 dark:text-danger-400 font-medium">*</sup>
                    <?php endif; ?>
                </span>
            </label>
        </div>

        <?php if (isset($component)) { $__componentOriginal505efd9768415fdb4543e8c564dad437 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal505efd9768415fdb4543e8c564dad437 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.input.wrapper','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::input.wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
            <?php if (isset($component)) { $__componentOriginal9ad6b66c56a2379ee0ba04e1e358c61e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ad6b66c56a2379ee0ba04e1e358c61e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.input.index','data' => ['type' => 'text','name' => ''.e($getName()).'','id' => ''.e($getId()).'','value' => ''.e($getState()).'','placeholder' => ''.e($getPlaceholder()).'','class' => 'w-full pr-10']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => ''.e($getName()).'','id' => ''.e($getId()).'','value' => ''.e($getState()).'','placeholder' => ''.e($getPlaceholder()).'','class' => 'w-full pr-10']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ad6b66c56a2379ee0ba04e1e358c61e)): ?>
<?php $attributes = $__attributesOriginal9ad6b66c56a2379ee0ba04e1e358c61e; ?>
<?php unset($__attributesOriginal9ad6b66c56a2379ee0ba04e1e358c61e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ad6b66c56a2379ee0ba04e1e358c61e)): ?>
<?php $component = $__componentOriginal9ad6b66c56a2379ee0ba04e1e358c61e; ?>
<?php unset($__componentOriginal9ad6b66c56a2379ee0ba04e1e358c61e); ?>
<?php endif; ?>

             <?php $__env->slot('suffix', null, []); ?> 
                <!-- Trigger Button for Filament Modal -->
                <button type="button" @click="openScannerModal()" class="flex items-center pr-3 focus:outline-none"
                        aria-label="Scan QrCode">
                    <?php if($getExtraAttributes()['icon'] ?? null): ?>
                        <span class="text-gray-400 dark:text-gray-200">
                            <?php if (isset($component)) { $__componentOriginal511d4862ff04963c3c16115c05a86a9d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal511d4862ff04963c3c16115c05a86a9d = $attributes; } ?>
<?php $component = Illuminate\View\DynamicComponent::resolve(['component' => $getExtraAttributes()['icon']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dynamic-component'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\DynamicComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $attributes = $__attributesOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__attributesOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal511d4862ff04963c3c16115c05a86a9d)): ?>
<?php $component = $__componentOriginal511d4862ff04963c3c16115c05a86a9d; ?>
<?php unset($__componentOriginal511d4862ff04963c3c16115c05a86a9d); ?>
<?php endif; ?>
                        </span>
                    <?php else: ?>
                        <svg class="w-5 h-5 text-gray-400 dark:text-gray-200" xmlns="http://www.w3.org/2000/svg"
                             xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" viewBox="0 0 16 16"
                             fill="currentColor">
                            <path fill="currentColor" d="M6 0h-6v6h6v-6zM5 5h-4v-4h4v4z"></path>
                            <path fill="currentColor" d="M2 2h2v2h-2v-2z"></path>
                            <path fill="currentColor" d="M0 16h6v-6h-6v6zM1 11h4v4h-4v-4z"></path>
                            <path fill="currentColor" d="M2 12h2v2h-2v-2z"></path>
                            <path fill="currentColor" d="M10 0v6h6v-6h-6zM15 5h-4v-4h4v4z"></path>
                            <path fill="currentColor" d="M12 2h2v2h-2v-2z"></path>
                            <path fill="currentColor" d="M2 7h-2v2h3v-1h-1z"></path>
                            <path fill="currentColor" d="M7 9h2v2h-2v-2z"></path>
                            <path fill="currentColor" d="M3 7h2v1h-2v-1z"></path>
                            <path fill="currentColor" d="M9 12h-2v1h1v1h1v-1z"></path>
                            <path fill="currentColor" d="M6 7v1h-1v1h2v-2z"></path>
                            <path fill="currentColor" d="M8 4h1v2h-1v-2z"></path>
                            <path fill="currentColor" d="M9 8v1h2v-2h-3v1z"></path>
                            <path fill="currentColor" d="M7 6h1v1h-1v-1z"></path>
                            <path fill="currentColor" d="M9 14h2v2h-2v-2z"></path>
                            <path fill="currentColor" d="M7 14h1v2h-1v-2z"></path>
                            <path fill="currentColor" d="M9 11h1v1h-1v-1z"></path>
                            <path fill="currentColor" d="M9 3v-2h-1v-1h-1v4h1v-1z"></path>
                            <path fill="currentColor" d="M12 14h1v2h-1v-2z"></path>
                            <path fill="currentColor" d="M12 12h2v1h-2v-1z"></path>
                            <path fill="currentColor" d="M11 13h1v1h-1v-1z"></path>
                            <path fill="currentColor" d="M10 12h1v1h-1v-1z"></path>
                            <path fill="currentColor" d="M14 10v1h1v1h1v-2h-1z"></path>
                            <path fill="currentColor" d="M15 13h-1v3h2v-2h-1z"></path>
                            <path fill="currentColor" d="M10 10v1h3v-2h-2v1z"></path>
                            <path fill="currentColor" d="M12 7v1h2v1h2v-2h-2z"></path>
                        </svg>
                    <?php endif; ?>
                </button>
             <?php $__env->endSlot(); ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal505efd9768415fdb4543e8c564dad437)): ?>
<?php $attributes = $__attributesOriginal505efd9768415fdb4543e8c564dad437; ?>
<?php unset($__attributesOriginal505efd9768415fdb4543e8c564dad437); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal505efd9768415fdb4543e8c564dad437)): ?>
<?php $component = $__componentOriginal505efd9768415fdb4543e8c564dad437; ?>
<?php unset($__componentOriginal505efd9768415fdb4543e8c564dad437); ?>
<?php endif; ?>

    </div>

    <!-- Filament Modal for QrCode Scanner -->
    <?php if (isset($component)) { $__componentOriginal0942a211c37469064369f887ae8d1cef = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0942a211c37469064369f887ae8d1cef = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.modal.index','data' => ['id' => 'qrcode-scanner-modal-'.e($getName()).'','width' => 'lg','closeByClickingAway' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'qrcode-scanner-modal-'.e($getName()).'','width' => 'lg','close-by-clicking-away' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
         <?php $__env->slot('header', null, []); ?> 
            <h2 class="text-lg font-semibold">
                Scan <?php echo e($getLabel() ?? 'QrCode'); ?>

            </h2>
         <?php $__env->endSlot(); ?>

        <div class="p-4">
            <div id="scanner-container">
                <div id="reader-<?php echo e($getName()); ?>" width="600px" height="600px"></div>
            </div>
        </div>

         <?php $__env->slot('footer', null, []); ?> 
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['@click' => 'closeScannerModal()','color' => 'danger']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['@click' => 'closeScannerModal()','color' => 'danger']); ?>
                Close
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
         <?php $__env->endSlot(); ?>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $attributes = $__attributesOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__attributesOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0942a211c37469064369f887ae8d1cef)): ?>
<?php $component = $__componentOriginal0942a211c37469064369f887ae8d1cef; ?>
<?php unset($__componentOriginal0942a211c37469064369f887ae8d1cef); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\projeotos\chamadosv2\vendor\jeffersongoncalves\filament-qrcode-field\resources\views\components\qrcode-input.blade.php ENDPATH**/ ?>