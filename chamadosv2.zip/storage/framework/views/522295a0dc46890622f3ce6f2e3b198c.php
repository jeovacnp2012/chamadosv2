<div class="bg-white border rounded shadow-sm p-3 mb-2">
    <div class="flex items-center justify-between gap-4">
        
        <div class="flex-1">
            <div class="text-xs text-gray-600 font-semibold uppercase">
                <?php echo e($message->user->name); ?>

            </div>

            <div class="text-sm text-gray-800 whitespace-pre-line">
                <?php echo e($message->message); ?>

            </div>

            <?php if($message->attachment_path): ?>
                <div class="mt-1 mb-2">
                    <a href="<?php echo e(Storage::url($message->attachment_path)); ?>"
                       target="_blank"
                       class="text-blue-600 underline text-xs">
                        Ver Anexo (<?php echo e(strtoupper(pathinfo($message->attachment_path, PATHINFO_EXTENSION))); ?>)
                    </a>
                </div>
            <?php endif; ?>

            <div class="text-xs text-gray-400 mt-3">
                <?php echo e($message->created_at->format('d/m/Y H:i')); ?>

            </div>
        </div>

        
        <div class="flex-shrink-0 ml-2">
            <?php if (isset($component)) { $__componentOriginal6330f08526bbb3ce2a0da37da512a11f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament::components.button.index','data' => ['color' => 'danger','size' => 'sm','wire:click' => 'deleteMessage('.e($message->id).')','icon' => 'heroicon-o-trash']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament::button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['color' => 'danger','size' => 'sm','wire:click' => 'deleteMessage('.e($message->id).')','icon' => 'heroicon-o-trash']); ?>
                Excluir
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $attributes = $__attributesOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__attributesOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f)): ?>
<?php $component = $__componentOriginal6330f08526bbb3ce2a0da37da512a11f; ?>
<?php unset($__componentOriginal6330f08526bbb3ce2a0da37da512a11f); ?>
<?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\projeotos\chamadosv2\resources\views\livewire\partials\message.blade.php ENDPATH**/ ?>