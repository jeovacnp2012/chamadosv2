<?php

namespace App\Contracts;

interface BelongsToCompanyInterface {}
