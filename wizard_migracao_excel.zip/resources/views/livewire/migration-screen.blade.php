<div class="max-w-xl mx-auto mt-10 bg-white p-6 rounded shadow">
@if($step === 1)
    <h2 class="text-2xl font-bold mb-4">Passo 1: Faça upload dos arquivos Excel</h2>
    <form wire:submit.prevent="nextStep">
        <input type="file" wire:model="uploadedFiles" multiple accept=".xlsx,.xls" class="mb-4 block">
        @error('uploadedFiles.*') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror

        @if(count($uploadedFiles) > 0)
            <div class="mb-4">
                <div class="font-bold">Arquivos detectados:</div>
                <ul class="list-disc pl-6 mt-2 text-sm">
                    @foreach($uploadedFiles as $file)
                        <li>{{ $file->getClientOriginalName() }}</li>
                    @endforeach
                </ul>
            </div>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Próximo</button>
            <button type="button" wire:click="resetUpload" class="ml-2 px-3 py-2 bg-gray-200 rounded">Limpar</button>
        @endif
    </form>
@endif

@if($step === 2)
    <h2 class="text-2xl font-bold mb-4">Passo 2: Selecione as tabelas a importar</h2>
    <form wire:submit.prevent="nextStep">
        <div class="mb-4">
            @foreach($detectedTables as $table => $path)
                <label class="flex items-center">
                    <input type="checkbox" wire:model="selectedTables" value="{{ $table }}" class="mr-2">
                    {{ $table }}
                </label>
            @endforeach
        </div>
        <div class="flex gap-3">
            <button wire:click.prevent="prevStep" type="button" class="px-4 py-2 rounded bg-gray-300">Voltar</button>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded" @if(count($selectedTables) == 0) disabled @endif>Próximo</button>
        </div>
    </form>
@endif

@if($step === 3)
    @php $currentTable = $selectedTables[$tableStep] ?? null; @endphp
    <h2 class="text-2xl font-bold mb-4">
        Passo 3: Mapeamento dos Campos - <span class="text-blue-700">{{ $currentTable }}</span>
        ({{ $tableStep + 1 }} de {{ count($selectedTables) }})
    </h2>

    @if($currentTable)
    <form wire:submit.prevent="nextStep">
        <div class="mb-4">
            <table class="min-w-full border text-xs">
                <thead>
                    <tr>
                        <th class="border p-2">Campo Origem</th>
                        <th class="border p-2">Campo Destino</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($tablesFields[$currentTable]['origem'] ?? [] as $field => $typeOrig)
                        @php
                            $destFields = $tablesFields[$currentTable]['destino'] ?? [];
                            $selectedThis = $fieldsMapping[$currentTable][$field] ?? '';
                            $alreadyMapped = collect($fieldsMapping[$currentTable])->except($field)->values()->all();
                        @endphp
                        <tr>
                            <td class="border p-2">{{ $field }}</td>
                            <td class="border p-2">
                                <select wire:model="fieldsMapping.{{ $currentTable }}.{{ $field }}" class="border rounded px-2 py-1">
                                    <option value="">Selecione</option>
                                    @foreach($destFields as $destKey => $destType)
                                        @if($selectedThis == $destKey || !in_array($destKey, $alreadyMapped))
                                            <option value="{{ $destKey }}">{{ $destKey }}</option>
                                        @endif
                                    @endforeach
                                </select>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <div class="flex gap-3 mt-6">
            @if($tableStep > 0)
                <button wire:click.prevent="prevStep" type="button" class="px-4 py-2 rounded bg-gray-300">Anterior</button>
            @endif
            <button type="submit"
                class="px-4 py-2 rounded bg-blue-600 text-white"
                @if(!$this->canProceedTable($currentTable)) disabled @endif
            >
                {{ $tableStep === count($selectedTables)-1 ? 'Confirmar Mapeamento' : 'Próximo' }}
            </button>
        </div>
    </form>
    @endif
@endif

@if($step === 4)
    <h2 class="text-2xl font-bold mb-4">Resumo e Execução da Migração</h2>
    <div class="mb-4">
        <div class="font-bold">Tabelas a serem migradas:</div>
        <ul class="list-disc pl-6 mt-2 text-sm">
            @foreach($selectedTables as $table)
                <li>{{ $table }}</li>
            @endforeach
        </ul>
    </div>
    <div class="flex gap-3 mt-6">
        <button wire:click="prevStep" type="button" class="px-4 py-2 rounded bg-gray-300">Voltar</button>
        <button wire:click="executeMigration" type="button" class="px-4 py-2 rounded bg-green-700 text-white"
            @if($isMigrating) disabled @endif>
            @if($isMigrating)
                Migrando...
            @else
                Executar Migração
            @endif
        </button>
    </div>
    @if($migrationResult)
        <div class="mt-6 p-4 rounded bg-{{ $migrationResult['success'] ? 'green' : 'red' }}-100 text-{{ $migrationResult['success'] ? 'green' : 'red' }}-700 text-sm">
            {!! nl2br(e($migrationResult['message'])) !!}
            @if($migrationResult['logfile'])
                <br><br>
                <a href="{{ asset($migrationResult['logfile']) }}" class="underline text-blue-700" target="_blank">
                    Baixar Log da Migração
                </a>
            @endif
        </div>
    @endif
@endif
</div>
