<?php

use App\Livewire\MigrationScreen;

Route::get('/migracao', MigrationScreen::class)->name('migration.screen');
