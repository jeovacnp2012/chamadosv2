<?php

namespace App\Livewire;

use Livewire\Component;
use Livewire\WithFileUploads;
use Maatwebsite\Excel\Facades\Excel;

class MigrationScreen extends Component
{
    use WithFileUploads;

    public int $step = 1;
    public $uploadedFiles = [];
    public $detectedTables = []; // ['nome_tabela' => 'caminho_tmp']
    public $selectedTables = [];
    public array $tablesFields = []; // [tabela => [fields]]
    public int $tableStep = 0;
    public array $fieldsMapping = [];
    public array $fieldsTypeDiffs = [];
    public bool $acceptAllTypeDiffs = false;

    public $isMigrating = false;
    public $migrationResult = null;

    // Para reset do wizard
    public function resetUpload()
    {
        $this->uploadedFiles = [];
        $this->detectedTables = [];
        $this->selectedTables = [];
        $this->step = 1;
        $this->tablesFields = [];
        $this->tableStep = 0;
        $this->fieldsMapping = [];
        $this->fieldsTypeDiffs = [];
        $this->isMigrating = false;
        $this->migrationResult = null;
    }

    // Passo 1: Upload dos arquivos
    public function updatedUploadedFiles()
    {
        $this->detectedTables = [];
        foreach ($this->uploadedFiles as $file) {
            $filename = pathinfo($file->getClientOriginalName(), PATHINFO_FILENAME);
            $table = str_replace([' ', '-'], '_', strtolower($filename));
            $this->detectedTables[$table] = $file->getRealPath();
        }
        $this->selectedTables = array_keys($this->detectedTables);
    }

    public function nextStep()
    {
        if ($this->step === 1) {
            if (count($this->uploadedFiles) === 0) return;
            $this->step = 2;
        } elseif ($this->step === 2) {
            if (count($this->selectedTables) === 0) return;
            $this->prepareTablesFields();
            $this->tableStep = 0;
            $this->step = 3;
        } elseif ($this->step === 3 && $this->tableStep < count($this->selectedTables) - 1) {
            $this->tableStep++;
        } elseif ($this->step === 3) {
            $this->step = 4;
        }
    }

    public function prevStep()
    {
        if ($this->step === 2) {
            $this->step = 1;
        } elseif ($this->step === 3 && $this->tableStep > 0) {
            $this->tableStep--;
        } elseif ($this->step === 3 && $this->tableStep === 0) {
            $this->step = 2;
        } elseif ($this->step === 4) {
            $this->step = 3;
        }
    }

    // Lê os campos (headings) dos arquivos Excel
    private function prepareTablesFields()
    {
        $this->tablesFields = [];
        $this->fieldsMapping = [];
        $this->fieldsTypeDiffs = [];
        foreach ($this->selectedTables as $table) {
            $filePath = $this->detectedTables[$table];
            $headings = Excel::toArray([], $filePath, null, \Maatwebsite\Excel\Excel::XLSX)[0][0] ?? [];
            if (empty($headings)) {
                $headings = Excel::toArray([], $filePath, null, \Maatwebsite\Excel\Excel::XLS)[0][0] ?? [];
            }
            $this->tablesFields[$table] = [
                'origem' => array_combine($headings, $headings),
                'destino' => $this->getTableColumns($table),
            ];
            // Sugestão automática de mapeamento
            foreach ($headings as $field) {
                if (isset($this->tablesFields[$table]['destino'][$field])) {
                    $this->fieldsMapping[$table][$field] = $field;
                } else {
                    $suggest = $this->suggestField($field, $this->tablesFields[$table]['destino']);
                    $this->fieldsMapping[$table][$field] = $suggest ?: '';
                }
            }
        }
    }

    private function getTableColumns($table)
    {
        $columns = [];
        try {
            $cols = \DB::connection('destino')->select("SHOW COLUMNS FROM `$table`");
            foreach ($cols as $col) {
                $columns[$col->Field] = $col->Type;
            }
        } catch (\Throwable $e) {}
        return $columns;
    }

    private function suggestField($field, $destFields)
    {
        foreach ($destFields as $dest => $type) {
            if (
                strpos($dest, $field) !== false ||
                strpos($field, $dest) !== false ||
                levenshtein($dest, $field) < 4
            ) {
                return $dest;
            }
        }
        return null;
    }

    // Para checar se pode avançar na tabela atual
    public function canProceedTable($table)
    {
        if (!isset($this->fieldsMapping[$table])) return false;
        $allMapped = !in_array('', $this->fieldsMapping[$table], true);
        $destValues = array_values($this->fieldsMapping[$table]);
        $hasDuplicates = count($destValues) !== count(array_unique($destValues));
        return $allMapped && !$hasDuplicates;
    }

    public function updatedFieldsMapping($value, $key)
    {
        // Se desejar: implementar comparação de tipos/campos aqui
    }

    // Migração final
    public function executeMigration()
    {
        $this->isMigrating = true;
        $log = [];
        $success = true;

        $filename = 'migracao-' . now()->format('Ymd-His') . '.txt';
        $logfile = base_path($filename);

        \DB::connection('destino')->beginTransaction();

        try {
            foreach ($this->selectedTables as $table) {
                $log[] = "Tabela: {$table}";

                $filePath = $this->detectedTables[$table];
                $dados = Excel::toArray([], $filePath, null, \Maatwebsite\Excel\Excel::XLSX)[0] ?? [];
                if (empty($dados)) {
                    $dados = Excel::toArray([], $filePath, null, \Maatwebsite\Excel\Excel::XLS)[0] ?? [];
                }
                // Remove heading
                $dados = array_slice($dados, 1);

                $destFields = $this->tablesFields[$table]['destino'] ?? [];
                $mapping = $this->fieldsMapping[$table] ?? [];

                $totalImported = 0;
                foreach ($dados as $row) {
                    $insert = [];
                    foreach ($mapping as $orig => $dest) {
                        if (!$dest) continue;
                        $idx = array_search($orig, array_keys($mapping));
                        $valor = $row[$idx] ?? null;
                        $insert[$dest] = $valor;
                    }
                    // Campos extras do destino como null/0
                    foreach ($destFields as $dest => $type) {
                        if (!in_array($dest, $mapping)) {
                            if (stripos($type, 'int') !== false or stripos($type, 'decimal') !== false or stripos($type, 'float') !== false) {
                                $insert[$dest] = 0;
                            } else {
                                $insert[$dest] = null;
                            }
                        }
                    }
                    if (!empty($insert)) {
                        \DB::connection('destino')->table($table)->insert($insert);
                        $totalImported++;
                    }
                }
                $log[] = "- Registros migrados: {$totalImported}";
                $log[] = "";
            }

            \DB::connection('destino')->commit();
            $log[] = "Migração concluída com sucesso!";
            $message = "Migração concluída com sucesso!\nLog salvo em: $filename";
        } catch (\Throwable $e) {
            $success = False;
            \DB::connection('destino')->rollBack();
            $log[] = "ERRO: " . $e->getMessage();
            $message = "Erro ao migrar: ".$e->getMessage()."\nNada foi alterado!";
        }

        file_put_contents($logfile, implode("\n", $log));

        $this->isMigrating = false;
        $this->migrationResult = [
            'success' => $success,
            'message' => $message,
            'logfile' => $success ? $filename : null
        ];

        // Excluir arquivos após uso
        foreach ($this->uploadedFiles as $file) {
            if ($file->exists()) $file->delete();
        }
    }

    public function render()
    {
        return view('livewire.migration-screen');
    }
}
